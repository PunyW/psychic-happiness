#!/bin/bash
# Execute at given hostname a given command

ssh $1 $2
