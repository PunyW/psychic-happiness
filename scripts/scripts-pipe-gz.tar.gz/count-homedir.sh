#!/bin/bash
# Counts how many files are in the home directory.

ls ~ | wc -l
