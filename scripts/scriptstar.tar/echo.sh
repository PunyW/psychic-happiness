#!/bin/bash
# Echoes command-line arguments

echo "$*"
